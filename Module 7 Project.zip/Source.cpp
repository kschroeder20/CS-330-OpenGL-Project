﻿#include <glad/glad.h>
#include <GLFW/glfw3.h>

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "shader.h"
#include "camera.h"
#include "Cylinder.h"

#include <iostream>

void framebuffer_size_callback(GLFWwindow* window, int width, int height);
void mouse_callback(GLFWwindow* window, double xpos, double ypos);
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset);
void processInput(GLFWwindow* window);
unsigned int loadTexture(const char* path);
void setUpPenTop();
void setUpPenTip();
void setUpTexturedCube();
void setUpNewPlane();
void setUpElongatedPyramid();

// settings
const unsigned int SCR_WIDTH = 800;
const unsigned int SCR_HEIGHT = 600;

// VBOs and VAOs
unsigned int VBO, VAO;
unsigned int VBO2, VAO2;
unsigned int VBO3, VAO3;
unsigned int VBO4, VAO4;
unsigned int VBO5, VAO5;
unsigned int VBO6, VAO6;
unsigned int VBO7, VAO7;
unsigned int VBO8, VAO8;
unsigned int VBO9, VAO9;
unsigned int VBO10, VAO10;
unsigned int VBO11, VAO11;
unsigned int VBO12, VAO12;
unsigned int VBO13, VAO13;

// camera
Camera gCamera(glm::vec3(0.0f, 2.0f, 6.0f));
float gLastX = SCR_WIDTH / 2.0f;
float gLastY = SCR_HEIGHT / 2.0f;
bool gFirstMouse = true;
bool twoDemensionalView = false;
float fov = 45.0f;

// timing
float gDeltaTime = 0.0f; // time between current frame and last frame
float gLastFrame = 0.0f;

// lighting
glm::vec3 lightPos(1.2f, 1.0f, 2.0f);

int main()
{
    // glfw: initialize and configure
    // ------------------------------
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    // glfw window creation
    // --------------------
    GLFWwindow* window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, "LearnOpenGL", NULL, NULL);
    if (window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return -1;
    }
    glfwMakeContextCurrent(window);
    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
    glfwSetCursorPosCallback(window, mouse_callback);
    glfwSetScrollCallback(window, scroll_callback);

    // tell GLFW to capture our mouse
    glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    // glad: load all OpenGL function pointers
    // ---------------------------------------
    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
    {
        std::cout << "Failed to initialize GLAD" << std::endl;
        return -1;
    }

    // configure global opengl state
    // -----------------------------
    glEnable(GL_DEPTH_TEST);

    // build and compile our shader zprogram
    // ------------------------------------
    Shader ourShader("shaderfiles//7.1.camera.vs", "shaderfiles//7.1.camera.fs");
    Shader lightingShader("shaderfiles/6.multiple_lights.vs", "shaderfiles/6.multiple_lights.fs");
    Shader lightCubeShader("shaderfiles/6.light_cube.vs", "shaderfiles/6.light_cube.fs");

    // set up vertex data (and buffer(s)) and configure vertex attributes
    // ------------------------------------------------------------------
    float vertices[] = {
        // positions          // normals           // texture coords
        5.0f, -0.2f, 5.0f,    1.0f, 0.0f, 0.0f,   1.0f, 0.0f,
        5.0f, -0.2f, -5.0f,   1.0f, 0.0f, 0.0f,   1.0f, 1.0f,
       -5.0f, -0.2f, 5.0f,    1.0f, 0.0f, 0.0f,   0.0f, 0.0f,

       -5.0f, -0.2f, 5.0f,    1.0f, 0.0f, 0.0f,   1.0f, 0.0f,
       -5.0f, -0.2f, -5.0f,   1.0f, 0.0f, 0.0f,   1.0f, 1.0f,
        5.0f, -0.2f, -5.0f,   1.0f, 0.0f, 0.0f,   0.0f, 0.0f,
    };
    // positions of the point lights
    glm::vec3 pointLightPositions[] = {
        glm::vec3(2.0f,  3.0f,  0.0f),
    };
    // first, configure the pyramid's VAO (and VBO)
    unsigned int VBO, floorVAO;
    glGenVertexArrays(1, &floorVAO);
    glGenBuffers(1, &VBO);

    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

    glBindVertexArray(floorVAO);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
    glEnableVertexAttribArray(2);

    // second, configure the light's VAO (VBO stays the same; the vertices are the same for the light object which is also a 3D pyramid)
    unsigned int lightCubeVAO;
    glGenVertexArrays(1, &lightCubeVAO);
    glBindVertexArray(lightCubeVAO);

    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    // note that we update the lamp's position attribute's stride to reflect the updated buffer data
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    // load textures (we now use a utility function to keep the code more organized)
    // -----------------------------------------------------------------------------
    unsigned int diffuseMap = loadTexture("table.jpg");
    unsigned int specularMap = loadTexture("table.jpg");

    // shader configuration
    // --------------------
    lightingShader.use();
    lightingShader.setInt("material.diffuse", 0);
    lightingShader.setInt("material.specular", 1);

    // load and create a texture
    // -------------------------
    unsigned int texture1, texture2, texture3, texture4, texture5, texture6, texture7;
    // texture 1
    // ---------
    glGenTextures(1, &texture1);
    glBindTexture(GL_TEXTURE_2D, texture1);
    // set the texture wrapping parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    // set texture filtering parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    // load image, create texture and generate mipmaps
    int width, height, nrChannels;
    stbi_set_flip_vertically_on_load(true); // tell stb_image.h to flip loaded texture's on the y-axis.
    unsigned char* data = stbi_load("brick_wall.jpg", &width, &height, &nrChannels, 0);
    if (data)
    {
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
        glGenerateMipmap(GL_TEXTURE_2D);
    }
    else
    {
        std::cout << "Failed to load texture" << std::endl;
    }
    stbi_image_free(data);

    // texture 2
    // ---------
    glGenTextures(1, &texture2);
    glBindTexture(GL_TEXTURE_2D, texture2);
    // set the texture wrapping parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    // set texture filtering parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    // load image, create texture and generate mipmaps
    data = stbi_load("pen_blue.jpg", &width, &height, &nrChannels, 0);
    if (data)
    {
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
        glGenerateMipmap(GL_TEXTURE_2D);
    }
    else
    {
        std::cout << "Failed to load texture" << std::endl;
    }
    stbi_image_free(data);

    // texture 3
    // ---------
    glGenTextures(1, &texture3);
    glBindTexture(GL_TEXTURE_2D, texture3);
    // set the texture wrapping parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    // set texture filtering parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    // load image, create texture and generate mipmaps
    data = stbi_load("table.jpg", &width, &height, &nrChannels, 0);
    if (data)
    {
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
        glGenerateMipmap(GL_TEXTURE_2D);
    }
    else
    {
        std::cout << "Failed to load texture" << std::endl;
    }
    stbi_image_free(data);

    // texture 4
    // ---------
    glGenTextures(1, &texture4);
    glBindTexture(GL_TEXTURE_2D, texture4);
    // set the texture wrapping parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    // set texture filtering parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    // load image, create texture and generate mipmaps
    data = stbi_load("pencil_wood.jpg", &width, &height, &nrChannels, 0);
    if (data)
    {
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width - 1, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
        glGenerateMipmap(GL_TEXTURE_2D);
    }
    else
    {
        std::cout << "Failed to load texture" << std::endl;
    }
    stbi_image_free(data);

    // texture 5
    // ---------
    glGenTextures(1, &texture5);
    glBindTexture(GL_TEXTURE_2D, texture5);
    // set the texture wrapping parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    // set texture filtering parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    // load image, create texture and generate mipmaps
    data = stbi_load("black_book_cover.jpg", &width, &height, &nrChannels, 0);
    if (data)
    {
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width - 1, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
        glGenerateMipmap(GL_TEXTURE_2D);
    }
    else
    {
        std::cout << "Failed to load texture" << std::endl;
    }
    stbi_image_free(data);

    // texture 6
    // ---------
    glGenTextures(1, &texture6);
    glBindTexture(GL_TEXTURE_2D, texture6);
    // set the texture wrapping parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    // set texture filtering parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    // load image, create texture and generate mipmaps
    data = stbi_load("white_paper.jpg", &width, &height, &nrChannels, 0);
    if (data)
    {
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width - 1, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
        glGenerateMipmap(GL_TEXTURE_2D);
    }
    else
    {
        std::cout << "Failed to load texture" << std::endl;
    }
    stbi_image_free(data);

    // texture 7
    // ---------
    glGenTextures(1, &texture7);
    glBindTexture(GL_TEXTURE_2D, texture7);
    // set the texture wrapping parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    // set texture filtering parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    // load image, create texture and generate mipmaps
    data = stbi_load("coffee_cup_blue.jpg", &width, &height, &nrChannels, 0);
    if (data)
    {
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width - 1, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
        glGenerateMipmap(GL_TEXTURE_2D);
    }
    else
    {
        std::cout << "Failed to load texture" << std::endl;
    }
    stbi_image_free(data);

    ourShader.use();
    ourShader.setInt("texture1", 0);
    ourShader.setInt("texture2", 1);
    ourShader.setInt("texture3", 2);
    ourShader.setInt("texture4", 3);
    ourShader.setInt("texture5", 4);
    ourShader.setInt("texture6", 5);
    ourShader.setInt("texture7", 6);

    // render loop
    // -----------
    while (!glfwWindowShouldClose(window))
    {
        // per-frame time logic
        // --------------------
        float currentFrame = glfwGetTime();
        gDeltaTime = currentFrame - gLastFrame;
        gLastFrame = currentFrame;

        // input
        // -----
        processInput(window);

        // render
        // ------
        glClearColor(0.1f, 0.1f, 0.1f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        /////// LIGHT SHADER SET UP ///////
        // be sure to activate shader when setting uniforms/drawing objects
        lightingShader.use();
        lightingShader.setVec3("viewPos", gCamera.Position);
        lightingShader.setVec3("material.diffuse", 1.0f, 0.0f, 1.0f);
        lightingShader.setVec3("material.specular", 1.0f, 1.0f, 1.0f);
        lightingShader.setFloat("material.shininess", 32.0f);

        // directional light
        lightingShader.setVec3("dirLight.direction", -0.2f, -1.0f, -0.3f);
        lightingShader.setVec3("dirLight.ambient", 0.05f, 0.05f, 0.05f);
        lightingShader.setVec3("dirLight.diffuse", 0.4f, 0.4f, 0.4f);
        lightingShader.setVec3("dirLight.specular", 0.5f, 0.5f, 0.5f);
        // point light 1
        lightingShader.setVec3("pointLights[0].position", pointLightPositions[0]);
        lightingShader.setVec3("pointLights[0].ambient", 0.4f, 0.4f, 0.3f); // Off-white color
        lightingShader.setVec3("pointLights[0].diffuse", 0.4f, 0.4f, 0.3f); // Off-white color
        lightingShader.setVec3("pointLights[0].specular", 0.4f, 0.4f, 0.3f); // Off-white color
        lightingShader.setFloat("pointLights[0].constant", 1.0f);
        lightingShader.setFloat("pointLights[0].linear", 0.09);
        lightingShader.setFloat("pointLights[0].quadratic", 0.032);
        // point light 2
        lightingShader.setVec3("pointLights[1].position", pointLightPositions[1]);
        lightingShader.setVec3("pointLights[1].ambient", 0.05f, 0.05f, 0.05f);
        lightingShader.setVec3("pointLights[1].diffuse", 0.0f, 0.6f, 0.0f);
        lightingShader.setVec3("pointLights[1].specular", 0.0f, 0.6f, 0.0f);
        lightingShader.setFloat("pointLights[1].constant", 1.0f);
        lightingShader.setFloat("pointLights[1].linear", 0.09);
        lightingShader.setFloat("pointLights[1].quadratic", 0.032);
        lightingShader.setFloat("pointLights[1].cutOff", glm::cos(glm::radians(12.5f)));
        lightingShader.setFloat("pointLights[1].outerCutOff", glm::cos(glm::radians(15.0f)));
        // point light 3
        lightingShader.setVec3("pointLights[2].position", pointLightPositions[2]);
        lightingShader.setVec3("pointLights[2].ambient", 0.05f, 0.05f, 0.05f);
        lightingShader.setVec3("pointLights[2].diffuse", 0.8f, 0.8f, 0.8f);
        lightingShader.setVec3("pointLights[2].specular", 1.0f, 1.0f, 1.0f);
        lightingShader.setFloat("pointLights[2].constant", 1.0f);
        lightingShader.setFloat("pointLights[2].linear", 0.09);
        lightingShader.setFloat("pointLights[2].quadratic", 0.032);
        // point light 4
        lightingShader.setVec3("pointLights[3].position", pointLightPositions[3]);
        lightingShader.setVec3("pointLights[3].ambient", 0.05f, 0.05f, 0.05f);
        lightingShader.setVec3("pointLights[3].diffuse", 0.8f, 0.8f, 0.8f);
        lightingShader.setVec3("pointLights[3].specular", 0.0f, 0.0f, 0.0f);
        lightingShader.setFloat("pointLights[3].constant", 1.0f);
        lightingShader.setFloat("pointLights[3].linear", 0.09);
        lightingShader.setFloat("pointLights[3].quadratic", 0.032);
        // spotLight
        lightingShader.setVec3("spotLight.position", gCamera.Position);
        lightingShader.setVec3("spotLight.direction", gCamera.Front);
        lightingShader.setVec3("spotLight.ambient", 0.0f, 0.0f, 0.0f);
        lightingShader.setVec3("spotLight.diffuse", 0.0f, 0.0f, 0.0f);
        lightingShader.setVec3("spotLight.specular", 0.0f, 0.0f, 0.0f);
        lightingShader.setFloat("spotLight.constant", 1.0f);
        lightingShader.setFloat("spotLight.linear", 0.09);
        lightingShader.setFloat("spotLight.quadratic", 0.032);
        lightingShader.setFloat("spotLight.cutOff", glm::cos(glm::radians(12.5f)));
        lightingShader.setFloat("spotLight.outerCutOff", glm::cos(glm::radians(15.0f)));

        // view/projection transformations
        glm::mat4 view = gCamera.GetViewMatrix();
        glm::mat4 projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)SCR_WIDTH / (GLfloat)SCR_HEIGHT, 0.1f, 100.0f);

        lightingShader.setMat4("projection", projection);
        lightingShader.setMat4("view", view);

        // world transformation
        glm::mat4 model = glm::mat4(1.0f);
        lightingShader.setMat4("model", model);

        // bind diffuse map
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, diffuseMap);
        // bind specular map
        glActiveTexture(GL_TEXTURE1);
        glBindTexture(GL_TEXTURE_2D, specularMap);

        /////// TABLE ///////
        // render containers
        glBindVertexArray(floorVAO);
        for (unsigned int i = 0; i < 1; i++)
        {
            // calculate the model matrix for each object and pass it to shader before drawing
            glm::mat4 model = glm::mat4(1.0f);
            model = glm::scale(model, glm::vec3(5.0f, 5.0f, 5.0f));
            lightingShader.setMat4("model", model);

            glDrawArrays(GL_TRIANGLES, 0, 36);
        }
        /////// LIGHT CUBE SHADER SET UP ///////
        // also draw the lamp object(s)
        lightCubeShader.use();
        lightCubeShader.setMat4("projection", projection);
        lightCubeShader.setMat4("view", view);

        /////// REFLECTIVE LIGHT ///////
        // we now draw as many light bulbs as we have point lights.
        glBindVertexArray(lightCubeVAO);
        for (unsigned int i = 0; i < 2; i++)
        {
            model = glm::mat4(1.0f);
            model = glm::translate(model, pointLightPositions[i]);
            model = glm::scale(model, glm::vec3(0.2f)); // Make it a smaller pyramid
            float angle = -45;
            model = glm::rotate(model, glm::radians(angle), glm::vec3(0.0f, 0.0f, 0.1f));
            lightCubeShader.setMat4("model", model);
            glDrawArrays(GL_TRIANGLES, 0, 36);
        }

        /////// NON-REFLECTIVE LIGHT ///////
        glBindVertexArray(VAO2);
        model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first
        model = glm::scale(model, glm::vec3(0.3f, 0.5f, 0.3f));
        model = glm::translate(model, glm::vec3(5.0f, 0.0f, 10.0f));
        lightCubeShader.setMat4("model", model);
        static_meshes_3D::Cylinder lightCylinder(1, 50, 1, true, true, true);
        lightCylinder.render();

        /////// OUR SHADER SET UP ///////
        // activate ourShader
        ourShader.use();

        // pass projection matrix to shader (note that in this case it could change every frame)
        if (twoDemensionalView == true) {
            // projection = glm::ortho(0.0f, (float)SCR_WIDTH, 0.0f, (float)SCR_HEIGHT, 0.1f, 100.0f);
            projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)SCR_WIDTH / (GLfloat)SCR_HEIGHT, 0.1f, 0.0f);
        }
        else {
            projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)SCR_WIDTH / (GLfloat)SCR_HEIGHT, 0.1f, 100.0f);
        }
        ourShader.setMat4("projection", projection);

        // camera/view transformation
        // view = glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);
        ourShader.setMat4("view", view);

        model = glm::mat4(1.0f);

        /////// PEN BASE ///////
        // bind textures on corresponding texture units
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, texture1);
        glActiveTexture(GL_TEXTURE1);
        glBindTexture(GL_TEXTURE_2D, texture2);
        glBindVertexArray(VAO2);
        model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first
        model = glm::rotate(model, glm::radians(90.0f), glm::vec3(0.0f, 0.0f, 1.0f));
        model = glm::scale(model, glm::vec3(0.1f, 5.0f, 0.1f));
        ourShader.setMat4("model", model);
        static_meshes_3D::Cylinder C(2, 50, 1, true, true, true);
        C.render();

        /////// PEN TOP ///////
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, texture4);
        glActiveTexture(GL_TEXTURE1);
        glBindTexture(GL_TEXTURE_2D, 0);
        glBindVertexArray(VAO4);
        model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first
        model = glm::scale(model, glm::vec3(1.0f, 0.85f, 0.9f));
        ourShader.setMat4("model", model);
        setUpPenTop();
        glDrawArrays(GL_TRIANGLES, 0, 36);

        /////// PEN TIP ///////
        // remove textures to add black tip
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, 0);
        glActiveTexture(GL_TEXTURE1);
        glBindTexture(GL_TEXTURE_2D, 0);
        glBindVertexArray(VAO5);
        model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first
        ourShader.setMat4("model", model);
        setUpPenTip();
        glDrawArrays(GL_TRIANGLES, 0, 36);

        /////// PAPER CLIP ///////
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, texture6);
        glBindVertexArray(VAO9);
        model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first
        model = glm::scale(model, glm::vec3(1.0f, 0.5f, 0.5f));
        model = glm::translate(model, glm::vec3(-1.0f, 0.0f, 1.5f));
        ourShader.setMat4("model", model);
        setUpElongatedPyramid();
        glDrawArrays(GL_TRIANGLES, 0, 36);

        /////// COFFEE CUP ///////
        // INSIDE
        glActiveTexture(GL_TEXTURE0); // remove textures
        glBindTexture(GL_TEXTURE_2D, 0);
        glActiveTexture(GL_TEXTURE1);
        glBindTexture(GL_TEXTURE_2D, 0);
        glBindVertexArray(VAO10);
        model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first
        model = glm::translate(model, glm::vec3(6.0f, 0.0f, 0.0f));
        ourShader.setMat4("model", model);
        static_meshes_3D::Cylinder coffeeCupInside(1.2, 50, 2.1, true, true, true);
        coffeeCupInside.render();

        // OUTSIDE
        glActiveTexture(GL_TEXTURE0); // Add outside texture
        glBindTexture(GL_TEXTURE_2D, texture7);
        glBindVertexArray(VAO11);
        static_meshes_3D::Cylinder coffeeCupOutside(1.5, 50, 2, true, true, true);
        coffeeCupOutside.render();

        /////// COFFEE CUP HANDLE ///////
        // INSIDE
        glActiveTexture(GL_TEXTURE0); // remove textures
        glBindTexture(GL_TEXTURE_2D, 0);
        glActiveTexture(GL_TEXTURE1);
        glBindTexture(GL_TEXTURE_2D, 0);
        glBindVertexArray(VAO12);
        model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first
        model = glm::rotate(model, glm::radians(90.0f), glm::vec3(0.0f, 0.0f, 1.0f));
        model = glm::translate(model, glm::vec3(0.0f, -6.0f, 1.5f));
        model = glm::scale(model, glm::vec3(1.5f, 1.0f, 1.5f));
        ourShader.setMat4("model", model);
        static_meshes_3D::Cylinder handleInside(0.4, 50, 0.6, true, true, true);
        handleInside.render();

        // OUTSIDE
        glActiveTexture(GL_TEXTURE0); // Add outside texture
        glBindTexture(GL_TEXTURE_2D, texture7);
        glBindVertexArray(VAO13);
        static_meshes_3D::Cylinder handleOutside(0.5, 50, 0.5, true, true, true);
        handleOutside.render();

        /////// BOOK ///////
        // add black book cover
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, texture5);
        glBindVertexArray(VAO7);
        model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first
        model = glm::scale(model, glm::vec3(10.0f, 0.5f, 7.0f));
        model = glm::translate(model, glm::vec3(0.0f, 0.0f, -0.7f));
        ourShader.setMat4("model", model);
        setUpTexturedCube();
        glDrawArrays(GL_TRIANGLES, 0, 36);

        // add white book pages
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, texture6);
        glBindVertexArray(VAO8);
        model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first
        model = glm::scale(model, glm::vec3(1.0f, 0.2f, 3.5f));
        model = glm::translate(model, glm::vec3(-5.02f, 0.0f, -1.4f));
        model = glm::rotate(model, glm::radians(90.0f), glm::vec3(0.0f, 0.0f, 1.0f));

        ourShader.setMat4("model", model);
        setUpNewPlane();
        glDrawArrays(GL_TRIANGLES, 0, 36);

        glBindVertexArray(VAO8);
        model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first
        model = glm::scale(model, glm::vec3(5.05f, 0.2f, 1.0f));
        model = glm::translate(model, glm::vec3(0.0f, 0.0f, -1.38f));
        model = glm::rotate(model, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));

        ourShader.setMat4("model", model);
        setUpNewPlane();
        glDrawArrays(GL_TRIANGLES, 0, 36);

        glBindVertexArray(VAO8);
        model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first
        model = glm::scale(model, glm::vec3(1.0f, 0.2f, 3.5f));
        model = glm::translate(model, glm::vec3(5.02f, 0.0f, -1.4f));
        model = glm::rotate(model, glm::radians(90.0f), glm::vec3(0.0f, 0.0f, 1.0f));

        ourShader.setMat4("model", model);
        setUpNewPlane();
        glDrawArrays(GL_TRIANGLES, 0, 36);

        // glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
        // -------------------------------------------------------------------------------
        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    // optional: de-allocate all resources once they've outlived their purpose:
    // ------------------------------------------------------------------------
    glDeleteVertexArrays(1, &floorVAO);
    glDeleteVertexArrays(1, &lightCubeVAO);
    glDeleteBuffers(1, &VBO);

    // glfw: terminate, clearing all previously allocated GLFW resources.
    // ------------------------------------------------------------------
    glfwTerminate();
    return 0;
}


// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
void processInput(GLFWwindow* window)
{
    static const float cameraSpeed = 2.5f;

    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS) // move camera forwards
        gCamera.ProcessKeyboard(FORWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS) // move camera backwards
        gCamera.ProcessKeyboard(BACKWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS) // move camera left
        gCamera.ProcessKeyboard(LEFT, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS) // move camera right
        gCamera.ProcessKeyboard(RIGHT, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS) // move camera up
        gCamera.ProcessKeyboard(UP, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS) // move camera down
        gCamera.ProcessKeyboard(DOWN, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS)
    {
        if (twoDemensionalView == true)
        {
            twoDemensionalView = false;
            glViewport(0, 0, SCR_WIDTH, SCR_HEIGHT);
        }
        else
        {
            twoDemensionalView = true;
            glViewport(0, 0, SCR_WIDTH, SCR_HEIGHT);
        }
    }
}

// glfw: whenever the window size changed (by OS or user resize) this callback function executes
// ---------------------------------------------------------------------------------------------
void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
    // make sure the viewport matches the new window dimensions; note that width and 
    // height will be significantly larger thaan specified on retina displays.
    glViewport(0, 0, width, height);
}

// glfw: whenever the mouse moves, this callback is called
// -------------------------------------------------------
void mouse_callback(GLFWwindow* window, double xpos, double ypos)
{
    if (gFirstMouse)
    {
        gLastX = xpos;
        gLastY = ypos;
        gFirstMouse = false;
    }

    float xoffset = xpos - gLastX;
    float yoffset = gLastY - ypos; // reversed since y-coordinates go from bottom to top

    gLastX = xpos;
    gLastY = ypos;

    gCamera.ProcessMouseMovement(xoffset, yoffset);
}

// glfw: whenever the mouse scroll wheel scrolls, this callback is called
// ----------------------------------------------------------------------
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset)
{
    gCamera.ProcessMouseScroll(yoffset);
}

// utility function for loading a 2D texture from file
// ---------------------------------------------------
unsigned int loadTexture(char const* path)
{
    unsigned int textureID;
    glGenTextures(1, &textureID);

    int width, height, nrComponents;
    unsigned char* data = stbi_load(path, &width, &height, &nrComponents, 0);
    if (data)
    {
        GLenum format;
        if (nrComponents == 1)
            format = GL_RED;
        else if (nrComponents == 3)
            format = GL_RGB;
        else if (nrComponents == 4)
            format = GL_RGBA;

        glBindTexture(GL_TEXTURE_2D, textureID);
        glTexImage2D(GL_TEXTURE_2D, 0, format, width, height, 0, format, GL_UNSIGNED_BYTE, data);
        glGenerateMipmap(GL_TEXTURE_2D);

        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        stbi_image_free(data);
    }
    else
    {
        std::cout << "Texture failed to load at path: " << path << std::endl;
        stbi_image_free(data);
    }

    return textureID;
}
// sets up top of pencil
void setUpPenTop() {
    float vertices[] = {
        // Vertex Positions       // Texture 
         2.502f,  0.19f,  0.21f,  0.0f, 1.0f,
         3.0f,    0.0f,   0.0f,   1.0,  0.5f,
         2.502f, -0.19f,  0.21f,  0.0f, 0.0f,

         2.502f,  0.19f, -0.21f,  0.0f, 0.0f,
         3.0f,    0.0f,   0.0f,   1.0f, 0.5f,
         2.502f, -0.19f, -0.21f,  0.5f, 1.0f,

         2.502f,  0.19f,  0.21f,  0.0f, 0.0f,
         3.0f,    0.0f,   0.0f,   1.0f, 0.5f,
         2.502f,  0.19f, -0.21f,  0.5f, 1.0f,

         2.502f, -0.19f,  0.21f,  0.0f, 0.0f,
         3.0f,    0.0f,   0.0f,   1.0f, 0.5f,
         2.502f, -0.19f, -0.21f,  0.5f, 1.0f,

         2.502f,  0.19f,  0.21f,  0.0f, 0.0f,
         2.502f,  0.19f,  0.0f,   1.0f, 0.5f,
         2.502f, -0.19f, -0.21f,  0.5f, 1.0f,

         2.502f,  0.19f,  0.21f,  0.0f, 0.0f,
         2.502f, -0.19f,  0.21f,  1.0f, 0.5f,
         2.502f, -0.19f, -0.21f,  0.5f, 1.0f,
    };
    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerTexture = 2;

    glGenVertexArrays(1, &VAO4);
    glGenBuffers(1, &VBO4);

    glBindVertexArray(VAO4);

    glBindBuffer(GL_ARRAY_BUFFER, VBO4);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

    int stride = sizeof(float) * (floatsPerVertex + floatsPerTexture);

    // position attribute
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, (void*)0);
    glEnableVertexAttribArray(0);
    // texture coord attribute
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, stride, (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);
}
// sets up tip of pencile
void setUpPenTip() {
    float vertices[] = {
        // Vertex Positions     // Texture 
         2.9f,  0.04f,  0.05f,  0.0f, 1.0f,
         3.0f,  0.0f,   0.0f,   1.0,  0.5f,
         2.9f, -0.04f,  0.05f,  0.0f, 0.0f,

         2.9f,  0.04f, -0.05f,  0.0f, 0.0f,
         3.0f,  0.0f,   0.0f,   1.0f, 0.5f,
         2.9f, -0.04f, -0.05f,  0.5f, 1.0f,

         2.9f,  0.04f,  0.05f,  0.0f, 0.0f,
         3.0f,  0.0f,   0.0f,   1.0f, 0.5f,
         2.9f,  0.04f, -0.05f,  0.5f, 1.0f,

         2.9f, -0.04f,  0.05f,  0.0f, 0.0f,
         3.0f,  0.0f,   0.0f,   1.0f, 0.5f,
         2.9f, -0.04f, -0.05f,  0.5f, 1.0f,

         2.9f,  0.04f,  0.05f,  0.0f, 0.0f,
         2.9f,  0.04f,  0.0f,   1.0f, 0.5f,
         2.9f, -0.04f, -0.05f,  0.5f, 1.0f,

         2.9f,  0.04f,  0.05f,  0.0f, 0.0f,
         2.9f, -0.04f,  0.05f,  1.0f, 0.5f,
         2.9f, -0.04f, -0.05f,  0.5f, 1.0f,
    };
    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerTexture = 2;

    glGenVertexArrays(1, &VAO5);
    glGenBuffers(1, &VBO5);

    glBindVertexArray(VAO5);

    glBindBuffer(GL_ARRAY_BUFFER, VBO5);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

    int stride = sizeof(float) * (floatsPerVertex + floatsPerTexture);

    // position attribute
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, (void*)0);
    glEnableVertexAttribArray(0);
    // texture coord attribute
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, stride, (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);
}
// cube with texture verticies
void setUpTexturedCube()
{
    float vertices[] = {
        // positions          // textures
        -0.5f, -0.5f, -0.5f,  0.0f,  0.0f,
         0.5f, -0.5f, -0.5f,  1.0f,  0.0f,
         0.5f,  0.5f, -0.5f,  1.0f,  1.0f,
         0.5f,  0.5f, -0.5f,  1.0f,  1.0f,
        -0.5f,  0.5f, -0.5f,  0.0f,  1.0f,
        -0.5f, -0.5f, -0.5f,  0.0f,  0.0f,

        -0.5f, -0.5f,  0.5f,  0.0f,  0.0f,
         0.5f, -0.5f,  0.5f,  1.0f,  0.0f,
         0.5f,  0.5f,  0.5f,  1.0f,  1.0f,
         0.5f,  0.5f,  0.5f,  1.0f,  1.0f,
        -0.5f,  0.5f,  0.5f,  0.0f,  1.0f,
        -0.5f, -0.5f,  0.5f,  0.0f,  0.0f,

        -0.5f,  0.5f,  0.5f, -1.0f,  0.0f,
        -0.5f,  0.5f, -0.5f, -1.0f,  1.0f,
        -0.5f, -0.5f, -0.5f, -1.0f,  1.0f,
        -0.5f, -0.5f, -0.5f, -1.0f,  1.0f,
        -0.5f, -0.5f,  0.5f, -1.0f,  0.0f,
        -0.5f,  0.5f,  0.5f, -1.0f,  0.0f,

         0.5f,  0.5f,  0.5f,  1.0f,  0.0f,
         0.5f,  0.5f, -0.5f,  1.0f,  1.0f,
         0.5f, -0.5f, -0.5f,  1.0f,  1.0f,
         0.5f, -0.5f, -0.5f,  1.0f,  1.0f,
         0.5f, -0.5f,  0.5f,  1.0f,  0.0f,
         0.5f,  0.5f,  0.5f,  1.0f,  0.0f,

        -0.5f, -0.5f, -0.5f,  0.0f,  1.0f,
         0.5f, -0.5f, -0.5f,  1.0f,  1.0f,
         0.5f, -0.5f,  0.5f,  1.0f,  0.0f,
         0.5f, -0.5f,  0.5f,  1.0f,  0.0f,
        -0.5f, -0.5f,  0.5f,  0.0f,  0.0f,
        -0.5f, -0.5f, -0.5f,  0.0f,  1.0f,

        -0.5f,  0.5f, -0.5f,  0.0f,  1.0f,
         0.5f,  0.5f, -0.5f,  1.0f,  1.0f,
         0.5f,  0.5f,  0.5f,  1.0f,  0.0f,
         0.5f,  0.5f,  0.5f,  1.0f,  0.0f,
        -0.5f,  0.5f,  0.5f,  0.0f,  0.0f,
        -0.5f,  0.5f, -0.5f,  0.0f,  1.0f
    };

    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerTexture = 2;

    glGenVertexArrays(1, &VAO7);
    glGenBuffers(1, &VBO7);

    glBindVertexArray(VAO7);

    glBindBuffer(GL_ARRAY_BUFFER, VBO7);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

    int stride = sizeof(float) * (floatsPerVertex + floatsPerTexture);

    // position attribute
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, (void*)0);
    glEnableVertexAttribArray(0);
    // texture coord attribute
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, stride, (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);
}
// function to develop verticies for a new plane
void setUpNewPlane()
{
    float vertices[] = {
        // positions           // texture
        1.0f, 0.0f,  1.0f,    1.0f, 0.0f,
        1.0f, 0.0f, -1.0f,    1.0f, 1.0f,
       -1.0f, 0.0f,  1.0f,    0.0f, 0.0f,

       -1.0f, 0.0f,  1.0f,    1.0f, 0.0f,
       -1.0f, 0.0f, -1.0f,    1.0f, 1.0f,
        1.0f, 0.0f, -1.0f,    0.0f, 0.0f,
    };

    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerTexture = 2;

    glGenVertexArrays(1, &VAO8);
    glGenBuffers(1, &VBO8);

    glBindVertexArray(VAO8);

    glBindBuffer(GL_ARRAY_BUFFER, VBO8);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

    int stride = sizeof(float) * (floatsPerVertex + floatsPerTexture);

    // position attribute
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, (void*)0);
    glEnableVertexAttribArray(0);
    // texture coord attribute
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, stride, (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);
}
// function to develop verticies for elongated pyramid
void setUpElongatedPyramid() {
    float vertices[] = {
        // Vertex Positions    // Texture
        2.0f, 0.0f, 0.0f,     0.0f, 0.0f,
        2.0f, 1.0f, 0.5f,     0.0f, 0.0f,
        2.0f, 0.0f, 1.0f,     0.0f, 0.0f,

        0.0f, 0.0f, 0.0f,     0.0f, 0.0f,
        0.0f, 1.0f, 0.5f,     0.0f, 0.0f,
        0.0f, 0.0f, 1.0f,     0.0f, 0.0f,

        0.0f, 0.0f, 0.0f,     0.0f, 1.0f,
        2.0f, 1.0f, 0.5f,     1.0f, 0.5f,
        0.0f, 1.0f, 0.5f,     0.0f, 0.0f,

        2.0f, 1.0f, 0.5f,     0.0f, 1.0f,
        2.0f, 0.0f, 0.0f,     1.0f, 0.5f,
        0.0f, 0.0f, 0.0f,     0.0f, 0.0f,

        0.0f, 0.0f, 1.0f,     0.0f, 1.0f,
        2.0f, 1.0f, 0.5f,     1.0f, 0.5f,
        0.0f, 1.0f, 0.5f,     0.0f, 0.0f,

        0.0f, 0.0f, 1.0f,     0.0f, 1.0f,
        2.0f, 0.0f, 1.0f,     1.0f, 0.5f,
        2.0f, 1.0f, 0.5f,     0.0f, 0.0f,

        0.0f, 0.0f, 1.0f,     0.0f, 1.0f,
        2.0f, 0.0f, 1.0f,     1.0f, 0.5f,
        2.0f, 0.0f, 0.0f,     0.0f, 0.0f,

        0.0f, 0.0f, 1.0f,     0.0f, 1.0f,
        0.0f, 0.0f, 1.0f,     1.0f, 0.5f,
        2.0f, 0.0f, 0.0f,     0.0f, 0.0f,
    };
    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerTexture = 2;

    glGenVertexArrays(1, &VAO9);
    glGenBuffers(1, &VBO9);

    glBindVertexArray(VAO9);

    glBindBuffer(GL_ARRAY_BUFFER, VBO9);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

    int stride = sizeof(float) * (floatsPerVertex + floatsPerTexture);

    // position attribute
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, (void*)0);
    glEnableVertexAttribArray(0);
    // texture coord attribute
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, stride, (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);
}
